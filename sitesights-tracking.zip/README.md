# SiteSights Tracking Plugin for Wordpress
The wordpress plugin for our sitesights.io tracking
